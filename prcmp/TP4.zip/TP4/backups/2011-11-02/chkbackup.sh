#!/bin/bash

if [ ! -d "backups" ]
	then mkdir backups
fi

if [ ! -d "backups/$(date +%F)" ]
	then	mkdir "backups/$(date +%F)" 
fi

for x in $*
do
find . -path "$./backups" -prune -o -name "*.$x" -exec cp {} -p "backups/$(date +%F)" \;

done
exit