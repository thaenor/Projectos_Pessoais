#!/bin/bash

a=0
b=0
for variavel in $(ls -R)
do 
echo $variavel
	if [ -d $variavel ]
	then 
		a=$((a+1))
									#variavel1=0
									#for variavel1 in $(ls $variavel)
									#do
									#echo $variavel1
									#done
	elif [ -f $variavel ]
	then 
		b=$((b+1))
		echo "numero de linhas no ficheiro $variavel � $(wc -l < $variavel)" 
		echo "numero de palavras no ficheiro $variavel � $(wc -w < $variavel)"
	fi
#echo "$variavel"

done

echo "existem $a direct�rios e $b ficheiros"
exit