#!/bin/bash
du
exit