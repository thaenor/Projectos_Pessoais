#!/bin/bash 

if [ -f $1 ]
then 
 more $1 

 else 
 echo "Erro, ficheiro nao encontrado" 
fi

exit