#!/bin/bash

if [ $# -eq 1 ]
then
	if  test -f $1
	then
		more $1
	else
		echo "ficheiro nao existente"
	fi
else
	echo "numero incorrecto de parametros"
fi
exit