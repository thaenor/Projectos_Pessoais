#!/bin/bash

find TELEMOVEIS -type f | wc -l